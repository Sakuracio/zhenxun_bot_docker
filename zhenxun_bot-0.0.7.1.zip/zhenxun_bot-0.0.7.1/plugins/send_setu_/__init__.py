import nonebot


nonebot.load_plugins("plugins/send_setu_")
