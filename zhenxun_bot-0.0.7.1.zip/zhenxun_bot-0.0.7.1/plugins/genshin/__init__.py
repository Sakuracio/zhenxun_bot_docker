import nonebot

nonebot.load_plugins("plugins/genshin")

