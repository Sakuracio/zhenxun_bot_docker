import nonebot


nonebot.load_plugins('basic_plugins/super_cmd')






